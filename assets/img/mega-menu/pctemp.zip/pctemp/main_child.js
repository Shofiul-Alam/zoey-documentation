(function($) {
    $(function() {

        $('.mpc-vc-products-categories-slider.mpcth-items-slider a').hover(
            function(){
                $(".tooltip-category-content").delay(5000).fadeIn();
                var contCategory = $(this).find('.category-content').html();
                contCategory= contCategory.replace("h1", "h2");
                $('.tooltip-category-content').empty();
                $('.tooltip-category-content').append(contCategory);

            },
            function(){
                $('.tooltip-category-content').stop(true, true).hide();
            }
        )

    });
})(jQuery);